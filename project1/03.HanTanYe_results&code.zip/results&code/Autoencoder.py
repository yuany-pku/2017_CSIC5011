#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Sun Oct  8 18:18:15 2017

@author: Ruijian
"""
import numpy as np
import pandas as pd
from numpy import linalg as LA
import math
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
from torch.autograd import Variable
import torch.utils.data as Data
import torchvision
import sklearn
# 超参数
EPOCH = 50
BATCH_SIZE = 10
LR = 0.005
 # 下过数据的话, 就可以设置成 False
r = np.genfromtxt("/Users/Ruijian/Desktop/2017_spring/mini_1/1111.csv",delimiter=',',usecols=np.arange(0,5813))
rr = pd.read_csv("/Users/Ruijian/Desktop/2017_spring/mini_1/1111.csv")
v = rr[[0]]
z = r[1:,3:]
z = np.transpose(z)
#z = sklearn.preprocessing.normalize(z)
z = torch.from_numpy(z).float()
#
train_dataset = Data.TensorDataset(data_tensor=z, target_tensor=z)
train_loader = Data.DataLoader(dataset=train_dataset, batch_size=BATCH_SIZE, shuffle=True, num_workers=2,)
#
class AutoEncoder(nn.Module):
    def __init__(self,in_dim,hidden_1,hidden_2):
        super(AutoEncoder, self).__init__()

        # 压缩
        self.encoder = nn.Sequential(
            nn.Linear(in_dim, hidden_1),
            nn.Dropout(0.5),
            nn.Sigmoid(),
            nn.Linear(hidden_1, hidden_2),
            #nn.Dropout(0.5),
            #nn.ReLU(),
            #nn.Linear(hidden_2, hidden_3),   # 压缩成3个特征, 进行 3D 图像可视化
        )
        # 解压
        self.decoder = nn.Sequential(
           # nn.Linear(hidden_3, hidden_2),
           #          nn.Dropout(0.5),
           # nn.ReLU(),
            nn.Linear(hidden_2, hidden_1),
            nn.Dropout(0.5),
            nn.Sigmoid(),
            nn.Linear(hidden_1, in_dim),
          )
    def forward(self, x):
        encoded = self.encoder(x)
        decoded = self.decoder(encoded)
        return encoded, decoded

autoencoder = AutoEncoder(500, 30, 5)
optimizer = torch.optim.Adam(autoencoder.parameters(),lr=LR,betas=(0.9,0.999),eps = 1e-6,weight_decay =1e-6)
loss_func = nn.MSELoss()

for epoch in range(EPOCH):
    running_loss = 0.0
    for step, (x, y) in enumerate(train_loader):
        b_x = Variable(x)   # batch x, shape (batch, 28*28)
        b_y = Variable(y)   # batch y, shape (batch, 28*28)
        #b_label = Variable(y)               # batch label

        encoded, decoded = autoencoder(b_x)

        loss = loss_func(decoded, b_y)      # mean square error
        running_loss += loss.data[0]
        optimizer.zero_grad()               # clear gradients for this training step
        loss.backward()                     # backpropagation, compute gradients
        optimizer.step()                    # apply gradientsf
        if step % 200 == 0:
           print('Epoch: ', epoch, '| train loss: %.4f' % running_loss)
zz,zzz = autoencoder(Variable(z))
zzz = zzz.data.numpy()
zz = zz.data.numpy()

from sklearn.cluster import KMeans
model = KMeans(n_clusters = 5)#,init = np.array(zz), n_init=1)
result=model.fit(zz)
labels = model.labels_
r1 = pd.Series(labels).value_counts()
print model.inertia_
#距离越小 聚类效果越好
print (r1)
from sklearn.cluster import KMeans
model = KMeans(n_clusters = 5)#,init = np.array(zz), n_init=1)
result=model.fit(zz)
labels = model.labels_
r1 = pd.Series(labels).value_counts()
print model.inertia_
#距离越小 聚类效果越好
print (r1)
#for i in range(5809):
   # if labels[i] == 0:
   #     labels[i] = 2
  #  elif labels[i] == 4:
   #     labels[i] = 0
  #  elif labels[i] == 3:
  #      labels[i] = 3
 #   elif labels[i] == 1:
  #      labels[i] = 1
  #  elif labels[i] == 2:
   #     labels[i] = 4
labels = pd.DataFrame(labels)

dd = pd.read_csv("/Users/Ruijian/Desktop/hh111.csv")
tt = np.concatenate([dd,labels],axis=1)
title = pd.DataFrame(tt)
title.to_csv("/Users/Ruijian/Desktop/autoencoder.csv")

print torch.from_numpy(zzz).float(),z


