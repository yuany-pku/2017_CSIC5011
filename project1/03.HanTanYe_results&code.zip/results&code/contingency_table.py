# -*- coding: utf-8 -*-
"""
Created on Wed Oct 11 15:54:35 2017

@author: Roger
"""

import pandas as pd
import numpy as np
from scipy.stats import chi2_contingency
import os 

np.set_printoptions(threshold=50)
#def chisq_of_df_cols(df, c1, c2):
#    groupsizes = df.groupby([c1, c2]).size()
#    ctsum = groupsizes.unstack(c1)
#    # fillna(0) is necessary to remove any NAs which will cause exceptions
#    return(chi2_contingency(ctsum.fillna(0)))
#
#test_df = pd.DataFrame([[0, 1], [1, 0], [0, 2], [0, 1], [0, 2]], columns=['var1', 'var2'])
#print test_df
#print chisq_of_df_cols(test_df, 'var1', 'var2')

os.chdir('/Users/Roger/Dropbox/nips_analysis/comparison')
autoen = pd.read_csv('5_class_Linearauto.csv')
svd = pd.read_csv('5_class_SVD.csv')
sig = pd.read_csv('5_class_Sigmauto.csv')
#pd.Series(autoen['1'].unique())

#get sizes of different classes of two methods
autoen['1'].value_counts()
autoclass = np.array(pd.Series(autoen['1'].value_counts()).sort_index())
svd['1'].value_counts()
svdclass = np.array(pd.Series(svd['1'].value_counts()).sort_index())
sig['1'].value_counts()
sigclass = np.array(pd.Series(sig['1'].value_counts()).sort_index())


totalclass = np.array([autoclass, svdclass])
print totalclass
print chi2_contingency(totalclass)

class2 = np.array([sigclass, svdclass])
print class2
print chi2_contingency(class2)