% err = [];
% for i = 1:99
%     err = [err,Compress(2, 5, i, V, Mean, IMG_SCALE)];
% end

T1 = [];
T2 = [];
T3 = [];
for unCertainty = 1000
    ix = random('unif',0,1,size(Src))<=unCertainty/380800;
    shifted_images_G_als = shifted_images;
    shifted_images_G_als(ix) = NaN;

    
    t = cputime;
    V_G_als2 = pca(shifted_images_G_als','Rows','complete');
    cputime-t
    
end