X=double(imread('dataset/FaceDetection.bmp'));

for i=1:(size(X,2)-SizeX)
    A=X(:,i:i+SizeY-1);
    imagesc(A);
    err(i)=ErrorProj(A, 99, V, Mean, IMG_SCALE);
end 

subplot(2,1,1);
imagesc(X);colormap('gray');
subplot(2,1,2);
plot(err,'.');