l = [];
e = [];
for unCertainty = 3800
    ix = random('unif',0,1,[3808,100])<=unCertainty/380800;
    shifted_images_G_als = shifted_images;
    shifted_images_G_als(ix) = NaN;

    temp = isnan(shifted_images_G_als);
    
    l = [l, sum(temp(:))/380800];
    
    shifted_images_G_als(temp) = 0;
    shifted_images_G_als = imgaussfilt(shifted_images_G_als);
    
    V_G_LD = pca(shifted_images_G_als','Rows','complete');

    e = [e,Compress(12, 5, 99, V_G_LD, Mean, IMG_SCALE)];
end
