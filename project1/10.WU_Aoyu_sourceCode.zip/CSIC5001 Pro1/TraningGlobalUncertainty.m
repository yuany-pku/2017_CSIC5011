

% for person_id=1:N_PERSON
%     for expression=1:N_EXPRESSION
%         A=imread(sprintf('dataset/s%i/%i.pgm',person_id,expression));
%         A=imresize(A,IMG_SCALE,'bicubic');
%         A=double(A);
%         Src(:,(person_id-1)*N_EXPRESSION+expression)=A(:);
%     end
% end
% num_points = size(Src,1);
% num_images = size(Src,2);
% 
% mean_face = mean(Src, 2);
% shifted_images = Src - repmat(mean_face, 1, num_images);
% 
% A=imread(sprintf('dataset/s%i/%i.pgm',2,6));
% A=imresize(A,IMG_SCALE,'bicubic');
errV = [];
errC = [];
T = [];
for unCertainty =0.0001:0.001:0.0001
    unCertainty
    t = cputime;
    ix = random('unif',0,1,size(Src))<unCertainty;
    shifted_images_G_als = shifted_images;
    shifted_images_G_als(ix) = NaN;
    V_G_als = pca(shifted_images_G_als','Rows','pairwise');
    errV = [errV, subspace(V,V_G_als)];
    errC = [errC, Compress(2, 6, 50, V_G_als, Mean, IMG_SCALE)];
    T = [T, cputime-t];
end
