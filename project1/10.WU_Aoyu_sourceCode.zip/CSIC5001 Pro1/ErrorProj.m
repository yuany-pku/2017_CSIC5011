function err = ErrorProj(A, space_dimension, V, Mean, IMG_SCALE)

close all;


% Mean(:)  stores the face mean
% V        stores the eigenvectors


% Generate the affine subspace G using the first space_dimension eigenvectors
affinesubspace(:,1:space_dimension)=V(:,1:space_dimension);

% Project into the affine subspace G 
Pr=double(A)-Mean;
local_coords=affinesubspace'*Pr(:);

% local_coords is represented using space_dimension values

% Reproject it back to the original coordinates
RePr=reshape(((affinesubspace*local_coords)+Mean(:)),size(A,1),size(A,2));


X=A(:)-RePr(:);
err=X'*X;
