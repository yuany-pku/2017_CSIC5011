close all;
clear all;
clc;

N_PERSON=20;
N_EXPRESSION=5;
IMG_SCALE=0.6;

for person_id=1:N_PERSON
    for expression=1:N_EXPRESSION
        A=imread(sprintf('dataset/s%i/%i.pgm',person_id,expression));
        A=imresize(A,IMG_SCALE,'bicubic');
        
        if (exist('Mean')~=1) 
            SizeX=size(A,1);
            SizeY=size(A,2);
            Mean=zeros(SizeX,SizeY); 
        end
        Mean=Mean+double(A);
        
        Img((SizeX*(expression-1))+1:(SizeX*expression),(SizeY*(person_id-1))+1:(SizeY*person_id))=A;
    end
end
Mean=Mean./(N_PERSON*N_EXPRESSION);

imshow(Img);
figure();imagesc(Mean);colormap('gray');

for person_id=1:N_PERSON
    for expression=1:N_EXPRESSION
        A=imread(sprintf('dataset/s%i/%i.pgm',person_id,expression));
        A=imresize(A,IMG_SCALE,'bicubic');
        A=double(A);
        Src(:,(person_id-1)*N_EXPRESSION+expression)=A(:);
    end
end
num_images = size(Src,2);
mean_face = mean(Src, 2);
shifted_images = Src - repmat(mean_face, 1, num_images);

V = pca(shifted_images');
