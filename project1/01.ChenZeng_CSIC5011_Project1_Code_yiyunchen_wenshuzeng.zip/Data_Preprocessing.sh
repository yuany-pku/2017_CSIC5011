#!/bin/bash

# step 1 select individuals from ind1
for i in `cat ind1.txt`; do sed -n "${i}p" ceph_hgdp_minor_code_XNA.txt >> step1.tmp; done

# transpose the data
datamash --no-strict transpose -t" " < step1.tmp > step1.T.tmp

# remove blank rows (after 644258)
cat step1.T.tmp | head -644258 > step2.tmp

# step 2 select SNPs from ind2
seq 644258 > l.tmp
paste l.tmp step2.tmp > step2.l.tmp
awk 'FNR==NR{a[$1];next}($1 in a){print $0}' ind2.txt step2.l.tmp > CleanData_2.txt
cat CleanData_2.txt | cut -f2-1044 > CleanData_final.txt
rm *.tmp

# match ind1 with their regions
for i in `cat ind1.txt`; do sed -n "${i}p" region.txt; done > ind1.region.txt
cat region.txt | sort -u
paste ind1.txt ind1.region.txt > INDEX.region.txt

# separate data file according to the 7 main regions
# transpose data for the ease of selecting individuals
datamash --no-strict transpose -t" " < CleanData_final.txt > CleanData_T.txt
# generate index of each individual
for i in `sort -u region.txt`; do let j=`sort -u region.txt | awk '{print NR"\t"$0}' | grep $i  | awk '{print $1}'`; cat INDEX.new.txt | grep $i | awk '{print $2"\t"$3}' > ${j}_${i}_index.txt; done
# generate corresponding line of index from clena data
for i in `sort -u region.txt`; do let j=`sort -u region.txt | awk '{print NR"\t"$0}' | grep $i  | awk '{print $1}'`; cat INDEX.new.txt | grep $i | awk '{print $1}' > ${j}_${i}_index.tmp; done
# export data according to index of the individuals in each population
for j in *.tmp; do for i in `cat $j`; do let n=`echo $j | sed -e "s/_index.tmp//g"`; sed -n "${i}p" CleanData_T.txt >> ${n}_data.txt ; done
rm *.tmp

