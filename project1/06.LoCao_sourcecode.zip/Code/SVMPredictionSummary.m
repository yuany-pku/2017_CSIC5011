% Author: Yi-Su Lo (yloab@connect.ust.hk)

function [sampurlab,samscolab,nononclass,nomulclass] = SVMPredictionSummary(samcat,samsco,lab)

%
nosam = size(samcat,1);
    
%
sampurlab = -1*ones(nosam,1);
samscolab = -1*ones(nosam,1);
nononclass = 0;  nomulclass = 0;
for isam = 1:nosam,
    if sum(samcat(isam,:))==1,
        sampurlab(isam) = lab(find(samcat(isam,:)==1));
        samscolab(isam) = sampurlab(isam);
    elseif sum(samcat(isam,:))==0,
        nononclass = nononclass + 1;
        sampurlab(isam) = -1;
        [~,ilabmax] = max(samsco(isam,:));
        samscolab(isam) = lab(ilabmax);
    elseif sum(samcat(isam,:))>1,
        nomulclass = nomulclass + 1;
        sampurlab(isam) = -1;
        [~,ilabmax] = max(samsco(isam,:));
        samscolab(isam) = lab(ilabmax);
    end
end