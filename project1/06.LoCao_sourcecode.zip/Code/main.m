% For Mini-Proj 1 of CSIC 5011 
% Author: Yi-Su Lo (yloab@connect.ust.hk) and Guiyu Cao 
% Oct 2017


%% presetting 
close all;  clear variables;


%% algorithm parameters
digpool = 0:9;      % assign the digits of interest
opt_rdim = 0;       % 0: PCA, 1: sparse PCA; 2: kernel PCA
dimfs = 16;         % set the dimension of the feature space
ifshowfs = 1;       % view the feature space (2D only)
ifdotest = 1;       % test the classifer with test set
ifshowerr = 1;      % show the wrongly classified samples 


%% load data
 
disp('------------------------------------------------------------------------');

% load training data
disp('Load the training set.');
[samtr,labtr] = LoadDigitData('./digits_ElemStatLearn/zipdata.train.mat',digpool);
nolab = length(digpool);  nosamtr = size(samtr,1);

% load test data
if ifdotest, 
    disp('Load the test set.');
    [samte,labte] = LoadDigitData('./digits_ElemStatLearn/zipdata.test',digpool);
    nosamte = size(samte,1);
end
 

%% dimension reduction

% reduce the dimension
disp('------------------------------------------------------------------------');
switch opt_rdim
    case 0
        % PCA
        disp(['Carry out PCA and make use of ',num2str(dimfs),' features.']);
        tic;
        [pcomp,coortr,~,~,ratexp,mutr] = pca(samtr);
        toc;
        coorfstr = coortr(:,1:dimfs);
    case 1
        % sparse PCA
        disp(['Carry out sparse PCA and make use of ',num2str(dimfs),' features.']);
        path(path,'./InvPow_SparsePCA_V2_0/');
        nocard = 32;
        tic;
        [pcomp,vars,varscum] = sparsePCA(samtr,nocard,dimfs);
        toc;
        coorfstr = samtr*pcomp; 
        %samtr_c = samtr - repmat(mean(samtr,1),nosamtr,1);
        %[pcomp,vars,varscum] = sparsePCA(samtr_c,nocard,dimfs);
        %coorfstr = samtr_c*pcomp;
    case 2
         % kernel PCA
        disp(['Carry out kernel PCA and make use of ',num2str(dimfs),' features.']);
        path(path,'./kPCA_v3.1/code/');
        tpkpcakerf = 'gaussian';
        dist = distanceMatrix(samtr);
        dist(dist==0) = inf;
        sigma = 5*mean(min(dist));
        %tpkpcakerf = 'poly';
        %sigma = 5;
        tic;
        [coorfstr,pcomp,eval] = kPCA(samtr,dimfs,tpkpcakerf,sigma);
        toc;
        %samtr_c = samtr - repmat(mean(samtr,1),nosamtr,1);
        %[coorfstr,pcomp,eval] = kPCA(samtr_c,dimfs,tpkpcakerf,sigma);
end

% show 2D feature space
if ifshowfs,
    figure;
    gscatter(coorfstr(:,1),coorfstr(:,2),labtr,[],'x');
    title('2D feature space');  xlabel('Score on the 1st principal component');  ylabel('Score on the 2nd principal component'); 

    if opt_rdim~=2,
        figure, imagesc(reshape(pcomp(:,1),16,16)'); colorbar; title('The 1st principal component');
        figure, imagesc(reshape(pcomp(:,2),16,16)'); colorbar; title('The 2nd principal component');       
    end
end



%% one-versus-the-rest SVM training

disp('------------------------------------------------------------------------');

% assign the type of kernel function
tpsvmkerf = 'rbf';

% SVM classifier training over erevy label
disp(['SVM with ',tpsvmkerf,' kernel function begins.']);
svmclf = cell(1,nolab);
for ilab = 1:nolab,        
    svmclf{ilab} = fitcsvm(coorfstr,(labtr==digpool(ilab)),'KernelFunc',tpsvmkerf,'Standardize',true,'KernelScale','auto');
end
if dimfs==2 && nolab<4 && ifshowregion, Show2DSVMRegions(svm,coorfstr,labtr,digpool); end


%% classification 

% classify the training set and compute the error rate
fittr_a = -1*ones(nosamtr,nolab);  fitscotr = zeros(nosamtr,nolab);
for ilab = 1:nolab,
    [fittr_a(:,ilab),sco] = predict(svmclf{ilab},coorfstr);
    fitscotr(:,ilab) = sco(:,2);
end
[fittr_p,fittr] = SVMPredictionSummary(fittr_a,fitscotr,digpool);
raterr = sum(fittr_p~=labtr)/nosamtr;
disp(['    The error rate in training: ',num2str(100*raterr,'%1.2f'),'%.']);
raterr = sum(fittr~=labtr)/nosamtr;
disp(['    The error rate in training (with distance rule): ',num2str(100*raterr,'%1.2f'),'%.']);

% classify the test set and compute the error rate 
if ifdotest,
    
    % compute the coordinate of test data points in the feature space
    switch opt_rdim
        case 0
            % PCA
            samte_c = samte - repmat(mutr,nosamte,1);
            coorte = samte_c*pcomp;
            coorfste = coorte(:,1:dimfs);
        case 1
            % sparse PCA
            coorfste = samte*pcomp;
            %samte_c = samte - repmat(mean(samtr,1),nosamte,1);
            %coorfste = samte_c*pcomp;
        case 2
            % kernel PCA
            coorfste = kPCA_NewData(samte,samtr,pcomp,tpkpcakerf,sigma);
            %samte_c = samte - repmat(mean(samtr,1),nosamte,1);
            %coorfste = kPCA_NewData(samte_c,samtr_c,pcomp,tpkpcakerf,sigma);
    end
    
    fitte_a = -1*ones(nosamte,nolab);  fitscote = zeros(nosamte,nolab);
    for ilab = 1:nolab,
        [fitte_a(:,ilab),sco] = predict(svmclf{ilab},coorfste);
        fitscote(:,ilab) = sco(:,2);
    end
    [fitte_p,fitte] = SVMPredictionSummary(fitte_a,fitscote,digpool);
    raterr = sum(fitte_p~=labte)/nosamte;
    disp(['    The error rate in test: ',num2str(100*raterr,'%1.2f'),'%.']);
    raterr = sum(fitte~=labte)/nosamte;
    disp(['    The error rate in test (with distance rule): ',num2str(100*raterr,'%1.2f'),'%.']);

    % show error samples in the test set
    if ifshowerr,
        idwste = find(fitte~=labte);
        figure;
        for isam = 1:min(10,length(idwste)),
            subplot(2,5,isam), ShowDigit(samte(idwste(isam),:)); 
            title(['label: ',num2str(labte(idwste(isam)))]);
            xlabel(['classified as ',num2str(fitte(idwste(isam)))]);
        end
    end
end