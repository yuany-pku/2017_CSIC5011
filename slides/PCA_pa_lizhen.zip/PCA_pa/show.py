import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import markers


Label = np.genfromtxt('test.csv', delimiter = ';', usecols = [0], dtype = ['S10'])
Class = np.genfromtxt('test.csv', delimiter = ';', usecols = [1], dtype = ['S60'])
Names = np.genfromtxt('test.csv', delimiter = ';', usecols = [2], dtype = ['S60'])
X = np.genfromtxt('test.csv', delimiter = ';')[:, 3:]

d = X.shape[1]
Category, ind = np.unique(Class, return_inverse = True)
nC = len(Category)

cmap = plt.cm.get_cmap('nipy_spectral')
mks = markers.MarkerStyle.filled_markers

plt.figure(figsize = (20, 10))
ax = plt.subplot(111)
for i in range(nC):
    subset = np.where(ind == i)[0]
    ax.scatter(X[subset, 0], X[subset, 1], s = 30,
                marker = mks[i], color = cmap(1.*i/nC), edgecolors = 'k', 
                label = r'%s'%(str(Category[i][0])[1:-2]))
ax.legend(loc = 'lower left')

plt.show()

#ax = plt.subplot(111)
#for j in range(d):
#    ax.plot(X[:, j], label = r'%s'%(j))
#ax.legend(loc = 'best')

#plt.show()
