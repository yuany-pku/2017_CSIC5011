
# Principal Components Analysis

pca <- function (data, corkind, nfactors, rotate, ppower, display) {

cnoms <- colnames(data) # get colnames

# determine whether data is a correlation matrix
if ( nrow(data) == ncol(data) ) {
if ( max(diag(data)) == 1 & min(diag(data)) == 1 ) {
datakind = 'correlations'}} else{ datakind = 'notcorrels'}

if (datakind == 'correlations') { cormat <- data }

if (datakind == 'notcorrels') {
Ncases <- nrow(data)
if (corkind=='pearson')     { cormat <- cor(data, method="pearson");  ctype <- 'Pearson'}
if (corkind=='kendall')     { cormat <- cor(data, method="kendall");  ctype <- 'Kendall' }
if (corkind=='spearman')    { cormat <- cor(data, method="spearman"); ctype <- 'Spearman' }
if (corkind=='polychoric')  { cormat <- polychoricR(data);            ctype <- 'Polychoric' }
}

eigval <- diag(eigen(cormat) $values)
eigvect <- eigen(cormat) $vectors
if (nfactors == 1) {loadings <- eigvect[,1:nfactors] * sqrt(eigval[1:nfactors,1:nfactors])
}else {loadings <- eigvect[,1:nfactors] %*% sqrt(eigval[1:nfactors,1:nfactors])}
loadings <- as.matrix(loadings)
rownames(loadings) <- cnoms
colnames(loadings) <- cbind(  (matrix( ("Factor"),1,ncol(loadings) )))

evalpca  <-  cbind(diag(eigval))
rownames(evalpca) <- 1:nrow(evalpca)
colnames(evalpca) <- "Eigenvalues"

if (rotate=='none')  { pcaOutput <- list( eigenvalues=evalpca, loadings=loadings ) }
if (rotate=='promax' | rotate=='varimax') {
if (ncol(loadings)==1) { loadingsROT <- loadings
pcaOutput <- list( eigenvalues=evalpca, loadingsNOROT=loadings ) } 
if (ncol(loadings) > 1) {
if (rotate=='varimax') { loadingsROT <- varimax(loadings,display='no')
pcaOutput <- list( eigenvalues=evalpca, loadingsNOROT=loadings, loadingsROT=loadingsROT ) }  
if (rotate=='promax')  { loadingsLIST <- promax(loadings,ppower,display='no')
pcaOutput <- list( eigenvalues=evalpca, structure=loadingsLIST$structure, pattern=loadingsLIST$pattern, correls=loadingsLIST$correls ) }
}}

if (display == 'yes') {
cat("\n\nPrincipal Components Analysis\n\n")
cat("\nSpecified kind of correlations for this analysis: ", ctype, "\n\n\n")
print(round(evalpca,2))
cat("\n\nUnrotated PCA Loadings:\n\n")
print(round(loadings[,1:nfactors],2));cat("\n")
if (ncol(loadings)==1) { cat("\n\nNo rotation because there is only one component\n\n") }
if (ncol(loadings) > 1) {
if (rotate=='none')    {cat("\n\nRotation Procedure:  No Rotation")}
if (rotate=='varimax') {cat("\n\nVarimax Rotated Loadings:\n\n"); print(round(loadingsROT,2));cat("\n\n") }
if (rotate=='promax')  { 
cat("\n\nPromax Rotation Structure Matrix:\n\n");    print(round(loadingsLIST$structure,2));cat("\n")
cat("\n\nPromax Rotation Pattern Matrix:\n\n");      print(round(loadingsLIST$pattern,2));cat("\n")
cat("\n\nPromax Rotation Factor Correlations:\n\n"); print(round(loadingsLIST$correls,2));cat("\n\n")
}}}

return(invisible(pcaOutput))

}
